# Spaceship Titanic - Logistic Regression Model

## Project Overview
This project implements a Logistic Regression model for predicting passenger transport status in the Spaceship Titanic dataset. The model uses Bayesian optimization (Optuna) for hyperparameter tuning and includes comprehensive performance analysis.

## Environment Setup

### Requirements
- Python 3.8+
- Required packages listed in `requirements.txt`
-A train.csv and test.csv in same directory
required packages:
pandas>=1.3.0
numpy>=1.21.0
scikit-learn>=1.0.0
matplotlib>=3.4.0
seaborn>=0.11.0
optuna>=3.0.0
Running：
Data_Analysis.py will input the data in train.csv  and output picture of analysis diagram as follows:{
missing_values.png - Missing data visualization

target_distribution.png - Target variable distribution

numerical_distributions.png - Histograms of numerical features

boxplots_outliers.png - Outlier detection plots

categorical_analysis.png - Categorical feature analysis

correlation_heatmap_fixed.png - Feature correlation matrix

age_by_transported.png - Age distribution analysis

spending_analysis.png - Spending behavior plots

spending_heatmap.png - Spending vs transportation heatmap

cabin_analysis.png - Cabin/deck analysis

bivariate_summary_fixed.png - Multi-feature relationship plots
}
logistic_regression_model.py will use data in train.csv to train alogistics regression model and output a submission.csv file which contain prediction data by using data in test.csv
Running steps:
Load and preprocess the data

Perform feature engineering

Run Optuna hyperparameter optimization (50 trials)

Train the final Logistic Regression model

Display performance metrics in the console

Generate submission.csv for Kaggle submission

Save performance_analysis.png with all visualizations