import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
import warnings
warnings.filterwarnings('ignore')

# Set style
plt.style.use('seaborn-v0_8-darkgrid')
sns.set_palette("viridis")
plt.rcParams['figure.figsize'] = (12, 6)
plt.rcParams['font.size'] = 10

# Load data
df = pd.read_csv('train.csv')
print("Dataset Shape:", df.shape)
print("\nFirst 5 rows:")
df.head()

#2 Data Overview and Missing Values
# Data types and missing values
info_df = pd.DataFrame({
    'Data Type': df.dtypes,
    'Missing Values': df.isnull().sum(),
    'Missing %': (df.isnull().sum() / len(df) * 100).round(2)
})
print(info_df)
fig, axes = plt.subplots(1, 2, figsize=(14, 5))

# Missing values bar plot
missing = df.isnull().sum().sort_values(ascending=False)
missing = missing[missing > 0]
axes[0].barh(missing.index, missing.values, color='steelblue')
axes[0].set_xlabel('Number of Missing Values')
axes[0].set_title('Missing Values by Column')

# Missing values heatmap
sns.heatmap(df.isnull(), yticklabels=False, cbar=True, cmap='viridis', ax=axes[1])
axes[1].set_title('Missing Values Pattern')

plt.tight_layout()
plt.savefig('missing_values.png', dpi=150, bbox_inches='tight')
plt.show()


#3 Target Variable Analysis
fig, axes = plt.subplots(1, 2, figsize=(12, 5))

# Count plot
colors = ['#2ecc71', '#e74c3c']
ax = axes[0]
transported_counts = df['Transported'].value_counts()
bars = ax.bar(['Not Transported', 'Transported'], transported_counts.values, color=colors)
ax.set_ylabel('Count')
ax.set_title('Target Variable Distribution')

# Add percentage labels
total = len(df)
for bar, count in zip(bars, transported_counts.values):
    height = bar.get_height()
    ax.text(bar.get_x() + bar.get_width()/2., height + 50,
            f'{count}\n({count/total*100:.1f}%)', ha='center', fontsize=11, fontweight='bold')

# Pie chart
axes[1].pie(transported_counts.values, labels=['Not Transported', 'Transported'],
            autopct='%1.1f%%', colors=colors, explode=(0, 0.05), shadow=True, startangle=90)
axes[1].set_title('Transportation Proportion')

plt.tight_layout()
plt.savefig('target_distribution.png', dpi=150, bbox_inches='tight')
plt.show()


#4 Numerical Features Analysis
num_cols = ['Age', 'RoomService', 'FoodCourt', 'ShoppingMall', 'Spa', 'VRDeck']
df[num_cols].describe().round(2)
#Distribution Analysis
fig, axes = plt.subplots(2, 3, figsize=(16, 10))
axes = axes.flatten()

for i, col in enumerate(num_cols):
    # Histogram with KDE
    ax = axes[i]
    
    # Filter extreme outliers for better visualization
    data = df[col].dropna()
    q99 = data.quantile(0.99)
    data_plot = data[data <= q99]
    
    sns.histplot(data_plot, kde=True, ax=ax, color='steelblue', bins=50)
    ax.axvline(data.median(), color='red', linestyle='--', label=f'Median: {data.median():.1f}')
    ax.axvline(data.mean(), color='green', linestyle='--', label=f'Mean: {data.mean():.1f}')
    ax.set_title(f'{col} Distribution (≤99th percentile)')
    ax.set_xlabel(col)
    ax.legend()

plt.tight_layout()
plt.savefig('numerical_distributions.png', dpi=150, bbox_inches='tight')
plt.show()
#  Boxplots for Outlier Detection
fig, axes = plt.subplots(2, 3, figsize=(16, 10))
axes = axes.flatten()

for i, col in enumerate(num_cols):
    ax = axes[i]
    
    # Create boxplot
    bp = ax.boxplot(df[col].dropna(), vert=True, patch_artist=True)
    bp['boxes'][0].set_facecolor('lightblue')
    
    # Add statistics
    data = df[col].dropna()
    q1, q3 = data.quantile(0.25), data.quantile(0.75)
    iqr = q3 - q1
    outliers = data[(data < q1 - 1.5*iqr) | (data > q3 + 1.5*iqr)]
    
    ax.set_ylabel(col)
    ax.set_title(f'{col}\nOutliers: {len(outliers)} ({len(outliers)/len(data)*100:.1f}%)')
    
    # Add text for stats
    ax.text(1.15, data.median(), f'Median: {data.median():.0f}', 
            verticalalignment='center', fontsize=9)

plt.tight_layout()
plt.savefig('boxplots_outliers.png', dpi=150, bbox_inches='tight')
plt.show()

#5 Categorical Features Analysis
cat_cols = ['HomePlanet', 'CryoSleep', 'Destination', 'VIP']

fig, axes = plt.subplots(2, 2, figsize=(14, 10))
axes = axes.flatten()

for i, col in enumerate(cat_cols):
    ax = axes[i]
    
    # Count plot with target hue
    data_plot = df.dropna(subset=[col])
    sns.countplot(data=data_plot, x=col, hue='Transported', ax=ax, palette=['#e74c3c', '#2ecc71'])
    
    ax.set_title(f'{col} Distribution by Transported Status')
    ax.set_xlabel(col)
    ax.set_ylabel('Count')
    
    # Add percentage labels
    for p in ax.patches:
        height = p.get_height()
        if height > 0:
            ax.text(p.get_x() + p.get_width()/2., height + 5,
                   f'{height}', ha='center', fontsize=8)

plt.tight_layout()
plt.savefig('categorical_analysis.png', dpi=150, bbox_inches='tight')
plt.show()
#6 Correlation Analysis
# Select numerical columns
# Select numerical columns
num_cols = ['Age', 'RoomService', 'FoodCourt', 'ShoppingMall', 'Spa', 'VRDeck']

# Remove rows with NaN for correlation calculation
corr_df = df[num_cols].dropna()

print(f"Rows for correlation: {len(corr_df)}")

# Calculate correlation matrix
corr_matrix = corr_df.corr()

# Create heatmap with proper label formatting
fig, ax = plt.subplots(figsize=(10, 8))
mask = np.triu(np.ones_like(corr_matrix, dtype=bool))

# Create heatmap with better label handling
sns.heatmap(corr_matrix, 
            mask=mask, 
            annot=True, 
            fmt='.2f', 
            cmap='RdBu_r', 
            center=0, 
            square=True, 
            linewidths=0.5, 
            ax=ax,
            cbar_kws={"shrink": 0.8},
            annot_kws={"size": 10},
            xticklabels=corr_matrix.columns,
            yticklabels=corr_matrix.index)

# Rotate x-axis labels for better readability
ax.set_xticklabels(ax.get_xticklabels(), rotation=45, ha='right', fontsize=10)
ax.set_yticklabels(ax.get_yticklabels(), rotation=0, fontsize=10)

ax.set_title('Correlation Matrix - Numerical Features', fontsize=14, fontweight='bold', pad=20)
plt.tight_layout()
plt.savefig('correlation_heatmap_fixed.png', dpi=150, bbox_inches='tight')
plt.show()

print("\nCorrelation Matrix:")
print(corr_matrix.round(3))



fig, axes = plt.subplots(1, 2, figsize=(14, 5))
#6Age Distribution by Transported Status
# Create age groups only for non-null ages
age_bins = [0, 12, 18, 30, 45, 60, 100]
age_labels = ['Child (0-12)', 'Teen (13-18)', 'Young Adult (19-30)', 
              'Adult (31-45)', 'Middle Age (46-60)', 'Senior (60+)']

df['AgeGroup'] = pd.cut(df['Age'].fillna(-1), bins=[-2] + age_bins, 
                         labels=['Missing'] + age_labels)
# Histogram by target
ax = axes[0]
for transported, color in zip([False, True], ['#e74c3c', '#2ecc71']):
    subset = df[df['Transported'] == transported]['Age'].dropna()
    ax.hist(subset, bins=30, alpha=0.6, label=f'Transported={transported}', color=color, density=True)
ax.set_xlabel('Age')
ax.set_ylabel('Density')
ax.set_title('Age Distribution by Transported Status')
ax.legend()

# Boxplot by target
ax = axes[1]
df.boxplot(column='Age', by='Transported', ax=ax, patch_artist=True,
           boxprops=dict(facecolor='lightblue'))
ax.set_title('Age by Transported Status')
ax.set_xlabel('Transported')
ax.set_ylabel('Age')
plt.suptitle('')

plt.tight_layout()
plt.savefig('age_by_transported.png', dpi=150, bbox_inches='tight')
plt.show()


#7 Spending Behavior Analysis
# Total Spending by Transported Status

# Calculate total spending (handle NaN as 0 for spending columns)
spending_cols = ['RoomService', 'FoodCourt', 'ShoppingMall', 'Spa', 'VRDeck']
df['TotalSpending'] = df[spending_cols].fillna(0).sum(axis=1)

# Create spending categories
df['SpendingCategory'] = pd.cut(df['TotalSpending'], 
                                 bins=[-1, 0, 100, 1000, 5000, float('inf')],
                                 labels=['Zero', 'Low (<100)', 'Medium (100-1k)', 
                                         'High (1k-5k)', 'Very High (>5k)'])

print("\nSpending Category Distribution:")
print(df['SpendingCategory'].value_counts())

fig, axes = plt.subplots(1, 3, figsize=(16, 5))

# Log-scale comparison
ax = axes[0]
for transported, color in zip([False, True], ['#e74c3c', '#2ecc71']):
    subset = df[df['Transported'] == transported]['TotalSpending'].dropna()
    subset_log = np.log1p(subset[subset > 0])
    ax.hist(subset_log, bins=40, alpha=0.6, label=f'Transported={transported}', 
            color=color, density=True)
ax.set_xlabel('Log(Total Spending + 1)')
ax.set_ylabel('Density')
ax.set_title('Total Spending Distribution (Log Scale)')
ax.legend()

# Boxplot
ax = axes[1]
spending_data = [df[df['Transported'] == False]['TotalSpending'].dropna().clip(upper=5000),
                 df[df['Transported'] == True]['TotalSpending'].dropna().clip(upper=5000)]
bp = ax.boxplot(spending_data, labels=['Not Transported', 'Transported'], patch_artist=True)
bp['boxes'][0].set_facecolor('#e74c3c')
bp['boxes'][1].set_facecolor('#2ecc71')
ax.set_ylabel('Total Spending (capped at 5000)')
ax.set_title('Total Spending by Transported Status')

# Zero spending analysis
ax = axes[2]
zero_spending = df.groupby('Transported').apply(
    lambda x: (x['TotalSpending'] == 0).sum() / len(x) * 100
)
bars = ax.bar(['Not Transported', 'Transported'], zero_spending.values, 
              color=['#e74c3c', '#2ecc71'])
ax.set_ylabel('Percentage (%)')
ax.set_title('Passengers with Zero Spending')
for bar, val in zip(bars, zero_spending.values):
    ax.text(bar.get_x() + bar.get_width()/2., bar.get_height() + 1,
            f'{val:.1f}%', ha='center', fontweight='bold')

plt.tight_layout()
plt.savefig('spending_analysis.png', dpi=150, bbox_inches='tight')
plt.show()
#Spending Pattern Heatmap
# Create spending categories
df['SpendingCategory'] = pd.cut(df['TotalSpending'], 
                                 bins=[-1, 0, 100, 1000, 5000, float('inf')],
                                 labels=['Zero', 'Low (<100)', 'Medium (100-1k)', 
                                         'High (1k-5k)', 'Very High (>5k)'])

# Cross-tabulation
spending_transport = pd.crosstab(df['SpendingCategory'], df['Transported'], normalize='index') * 100

fig, ax = plt.subplots(figsize=(10, 6))
sns.heatmap(spending_transport, annot=True, fmt='.1f', cmap='RdYlGn', 
            cbar_kws={'label': 'Transported %'}, ax=ax, linewidths=0.5)
ax.set_title('Transportation Rate by Spending Category', fontsize=14, fontweight='bold')
ax.set_xlabel('Transported')
ax.set_ylabel('Spending Category')

plt.tight_layout()
plt.savefig('spending_heatmap.png', dpi=150, bbox_inches='tight')
plt.show()

#8 Cabin Analysis

# Extract Deck from Cabin (first character, handle missing/empty)
df['Deck'] = df['Cabin'].fillna('').astype(str).str[0]
df['Deck'] = df['Deck'].replace('', np.nan)  # Empty string to NaN

# Extract Room Number safely
def extract_room_number(cabin):
    if pd.isna(cabin) or cabin == '':
        return np.nan
    parts = str(cabin).split('/')
    if len(parts) >= 2:
        room_part = parts[0]  # e.g., "B/0/P" -> "B"
        if len(room_part) > 1:
            try:
                return float(room_part[1:])
            except:
                return np.nan
    return np.nan

df['RoomNumber'] = df['Cabin'].apply(extract_room_number)

# Extract Side safely
def extract_side(cabin):
    if pd.isna(cabin) or cabin == '':
        return np.nan
    parts = str(cabin).split('/')
    if len(parts) >= 3:
        return parts[-1]
    return np.nan

df['Side'] = df['Cabin'].apply(extract_side)

# Deck distribution
fig, axes = plt.subplots(1, 3, figsize=(16, 5))

# Deck count plot - only use decks that actually exist in the data
ax = axes[0]
valid_decks = df['Deck'].dropna()
deck_order = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'T']
# Filter to only include decks present in the data
deck_order = [d for d in deck_order if d in valid_decks.unique()]

if len(deck_order) > 0:
    sns.countplot(data=df.dropna(subset=['Deck']), x='Deck', hue='Transported', 
                  ax=ax, order=deck_order, palette=['#e74c3c', '#2ecc71'])
    ax.set_title('Passenger Count by Deck')
    ax.set_xlabel('Deck')
    
    # Add legend with proper labels
    handles, labels = ax.get_legend_handles_labels()
    ax.legend(handles, ['Not Transported', 'Transported'])
else:
    ax.text(0.5, 0.5, 'No Deck data available', ha='center', va='center')
    ax.set_title('Passenger Count by Deck - No Data')

# Transportation rate by deck
ax = axes[1]
if len(valid_decks) > 0:
    deck_rates = df.dropna(subset=['Deck']).groupby('Deck')['Transported'].mean().sort_values() * 100
    colors_deck = ['#e74c3c' if x < 50 else '#2ecc71' for x in deck_rates.values]
    bars = ax.barh(deck_rates.index, deck_rates.values, color=colors_deck)
    ax.axvline(50, color='black', linestyle='--', alpha=0.5)
    ax.set_xlabel('Transportation Rate (%)')
    ax.set_title('Transportation Rate by Deck')
    
    # Add value labels
    for bar, val in zip(bars, deck_rates.values):
        ax.text(bar.get_width() + 0.5, bar.get_y() + bar.get_height()/2, 
                f'{val:.1f}%', va='center', fontsize=9)
else:
    ax.text(0.5, 0.5, 'No Deck data available', ha='center', va='center')

# Side analysis
ax = axes[2]
valid_sides = df['Side'].dropna()
if len(valid_sides) > 0:
    side_rates = df.dropna(subset=['Side']).groupby('Side')['Transported'].mean() * 100
    colors_side = ['#3498db', '#9b59b6', '#95a5a6'][:len(side_rates)]
    bars = ax.bar(side_rates.index, side_rates.values, color=colors_side)
    ax.set_ylabel('Transportation Rate (%)')
    ax.set_title('Transportation Rate by Cabin Side')
    
    for bar, val in zip(bars, side_rates.values):
        ax.text(bar.get_x() + bar.get_width()/2., bar.get_height() + 0.5,
                f'{val:.1f}%', ha='center', fontsize=10, fontweight='bold')
else:
    ax.text(0.5, 0.5, 'No Side data available', ha='center', va='center')

plt.tight_layout()
plt.savefig('cabin_analysis.png', dpi=150, bbox_inches='tight')
plt.show()

# ============================================
# FIX 4: AGE GROUP - REMOVE DUPLICATE CREATION
# ============================================

# Remove the duplicate age group creation in section 10
# Use the existing AgeGroup if it exists, or create it once

# Check if AgeGroup already exists with 'Missing' category
if 'AgeGroup' in df.columns and 'Missing' in df['AgeGroup'].cat.categories:
    # Remove 'Missing' category for analysis
    df_age_clean = df[df['AgeGroup'] != 'Missing'].copy()
else:
    # Create clean age groups without missing category
    age_bins = [0, 12, 18, 30, 45, 60, 100]
    age_labels = ['Child (0-12)', 'Teen (13-18)', 'Young Adult (19-30)', 
                  'Adult (31-45)', 'Middle Age (46-60)', 'Senior (60+)']
    df['AgeGroup'] = pd.cut(df['Age'], bins=age_bins, labels=age_labels)
    df_age_clean = df.dropna(subset=['AgeGroup']).copy()

#9 Key Bivariate Relationships Summary
# Create summary visualization
fig, axes = plt.subplots(2, 3, figsize=(16, 10))
axes = axes.flatten()

# 1. HomePlanet + CryoSleep
ax = axes[0]
pivot1 = df.pivot_table(index='HomePlanet', columns='CryoSleep', 
                         values='Transported', aggfunc='mean', observed=True) * 100
if not pivot1.empty:
    sns.heatmap(pivot1, annot=True, fmt='.1f', cmap='RdYlGn', ax=ax, 
                cbar_kws={'label': 'Transported %'})
    ax.set_title('Transportation Rate: HomePlanet × CryoSleep')
else:
    ax.text(0.5, 0.5, 'No data available', ha='center', va='center')

# 2. Destination + VIP
ax = axes[1]
pivot2 = df.pivot_table(index='Destination', columns='VIP', 
                         values='Transported', aggfunc='mean', observed=True) * 100
if not pivot2.empty:
    sns.heatmap(pivot2, annot=True, fmt='.1f', cmap='RdYlGn', ax=ax,
                cbar_kws={'label': 'Transported %'})
    ax.set_title('Transportation Rate: Destination × VIP')
else:
    ax.text(0.5, 0.5, 'No data available', ha='center', va='center')

# 3. Deck + Side
ax = axes[2]
deck_side_data = df.dropna(subset=['Deck', 'Side'])
if len(deck_side_data) > 0:
    pivot3 = deck_side_data.pivot_table(index='Deck', columns='Side', 
                                         values='Transported', aggfunc='mean', observed=True) * 100
    sns.heatmap(pivot3, annot=True, fmt='.1f', cmap='RdYlGn', ax=ax,
                cbar_kws={'label': 'Transported %'})
    ax.set_title('Transportation Rate: Deck × Side')
else:
    ax.text(0.5, 0.5, 'No Deck/Side data available', ha='center', va='center')

# 4. Age distribution by CryoSleep
ax = axes[3]
for cryo, color in zip([False, True], ['#e74c3c', '#2ecc71']):
    subset = df[df['CryoSleep'] == cryo]['Age'].dropna()
    if len(subset) > 0:
        ax.hist(subset, bins=25, alpha=0.5, label=f'CryoSleep={cryo}', color=color, density=True)
ax.set_xlabel('Age')
ax.set_ylabel('Density')
ax.set_title('Age Distribution by CryoSleep Status')
ax.legend()

# 5. Spending by HomePlanet
ax = axes[4]
homeplanet_spending = df.dropna(subset=['HomePlanet']).groupby('HomePlanet')['TotalSpending'].median()
if len(homeplanet_spending) > 0:
    bars = ax.bar(homeplanet_spending.index, homeplanet_spending.values, 
                  color=['#3498db', '#e67e22', '#2ecc71'])
    ax.set_ylabel('Median Total Spending')
    ax.set_title('Median Spending by HomePlanet')
    for bar, val in zip(bars, homeplanet_spending.values):
        ax.text(bar.get_x() + bar.get_width()/2., bar.get_height() + 5,
                f'{val:.0f}', ha='center')
else:
    ax.text(0.5, 0.5, 'No HomePlanet data available', ha='center', va='center')

# 6. Transportation rate by Age Group (using clean age groups)
ax = axes[5]
age_transport = df_age_clean.groupby('AgeGroup', observed=True)['Transported'].mean() * 100
colors_age = ['#e74c3c' if x < 50 else '#2ecc71' for x in age_transport.values]
bars = ax.bar(range(len(age_transport)), age_transport.values, color=colors_age)
ax.set_xticks(range(len(age_transport)))
ax.set_xticklabels(age_transport.index, rotation=45, ha='right')
ax.axhline(50, color='black', linestyle='--', alpha=0.5)
ax.set_ylabel('Transportation Rate (%)')
ax.set_title('Transportation Rate by Age Group')

for bar, val in zip(bars, age_transport.values):
    ax.text(bar.get_x() + bar.get_width()/2., bar.get_height() + 0.5,
            f'{val:.1f}%', ha='center', fontsize=9)

plt.tight_layout()
plt.savefig('bivariate_summary_fixed.png', dpi=150, bbox_inches='tight')
plt.show()
print("\n" + "="*50)
print("TRANSPORTATION RATE SUMMARY")
print("="*50)

# By HomePlanet
print("\n--- HomePlanet ---")
homeplanet_rates = df.groupby('HomePlanet')['Transported'].agg(['count', 'mean'])
homeplanet_rates['mean'] = homeplanet_rates['mean'] * 100
homeplanet_rates.columns = ['Count', 'Transported %']
print(homeplanet_rates.round(1))

# By CryoSleep
print("\n--- CryoSleep ---")
cryo_rates = df.groupby('CryoSleep')['Transported'].agg(['count', 'mean'])
cryo_rates['mean'] = cryo_rates['mean'] * 100
cryo_rates.columns = ['Count', 'Transported %']
print(cryo_rates.round(1))

# By Spending Category
print("\n--- Spending Category ---")
spending_rates = df.groupby('SpendingCategory', observed=True)['Transported'].agg(['count', 'mean'])
spending_rates['mean'] = spending_rates['mean'] * 100
spending_rates.columns = ['Count', 'Transported %']
print(spending_rates.round(1))

# By Deck
print("\n--- Deck ---")
deck_rates = df.dropna(subset=['Deck']).groupby('Deck')['Transported'].agg(['count', 'mean'])
deck_rates['mean'] = deck_rates['mean'] * 100
deck_rates.columns = ['Count', 'Transported %']
print(deck_rates.round(1).sort_values('Transported %', ascending=False))








